from dataclasses import dataclass

@dataclass
class Config:
    atom_id: int
    mass_data: dict
    data_file: str
    run_line: str
    init_n: int = 16
    probe_n: int = 10000
    batch_q: int = 10
    imse_tol: float = 0.1
    max_iters: int = 10
    random_seed: int = 123
