from setuptools import setup
setup(name='DEmap',
    version='0.2.0',    
    description='A example Python package',
    author='Ashley Dickson',
    author_email='a.dickson2@lancaster.ac.uk',
    license='BSD 2-clause',
    packages=['DEmap'],
    install_requires=['gpytorch',
                      'numpy', 'torch'                     
                      ]
)
